﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SciWpfUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const double CircleRadius = 6.0;

        private double cavasRealWidth = 0;
        private double cavasRealHeight = 0;

        /// <summary>
        /// new axes
        /// </summary>
        private double xx = 0;
        /// <summary>
        /// new axes
        /// </summary>
        private double yy = 0;

        private double alphaX = 0;
        private double alphaY = 0;

        private string pyPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

        private List<Tuple<double, double, string, Shape>> shapeList = new List<Tuple<double, double, string, Shape>>();

        private List<Tuple<double, double, string, Shape>> tmpSelectList = new List<Tuple<double, double, string, Shape>>();

        public MainWindow()
        {
            InitializeComponent();
            //full screen
            WindowState = WindowState.Maximized;
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            pyPath = System.IO.Path.Combine(pyPath, "cspy");
        }

        public MainWindow(bool popup)
        {
            InitializeComponent();
            isPopUp = true;
            MainCanvas.ContextMenu = null;
            controlGrid.Visibility = Visibility.Collapsed;
            ResizeMode = ResizeMode.NoResize;
            pyPath = System.IO.Path.Combine(pyPath, "cspy");

            Task.Run(() =>
            {
                Task.Delay(200).Wait();
                Dispatcher.Invoke(() => LoadResult());
            });
        }



        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            drawAxes();
        }

        //quit when esc or q key pressed
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape || e.Key == Key.Q)
                Close();
            else
            {
                if (isPopUp) return;

                switch (e.Key)
                {
                    case Key.D0:
                        tbClass.Text = "0";
                        break;
                    case Key.D1:
                        tbClass.Text = "1";
                        break;
                    case Key.D2:
                        tbClass.Text = "2";
                        break;
                    case Key.D3:
                        tbClass.Text = "3";
                        break;
                    case Key.D4:
                        tbClass.Text = "4";
                        break;
                    case Key.D5:
                        tbClass.Text = "5";
                        break;
                    case Key.D6:
                        tbClass.Text = "6";
                        break;
                    case Key.D7:
                        tbClass.Text = "7";
                        break;
                    case Key.D8:
                        tbClass.Text = "8";
                        break;
                    case Key.D9:
                        tbClass.Text = "9";
                        break;
                }
            }
        }

        private void MainCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (isPopUp) return;

            var p = e.GetPosition(MainCanvas);

            if (p.X - CircleRadius / 2 > 0 && p.Y - CircleRadius / 2 > 0)
            {
                drawDot(CircleRadius, CircleRadius, p.X - CircleRadius / 2, p.Y - CircleRadius / 2);
            }
        }

        private void MainCanvas_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (isPopUp)
            {
                e.Handled = true;
                return;
            }

            var p = e.GetPosition(MainCanvas);
            tmpSelectList.Clear();

            foreach (var tmp in shapeList)
            {
                if (tmp.Item4 is Line)
                {

                }
                else
                {
                    if (tmp.Item1 == p.X && tmp.Item2 == p.Y)
                    {
                        tmpSelectList.Add(tmp);
                    }
                    else
                    {
                        double a = tmp.Item1 + CircleRadius / 2 - p.X;
                        double b = tmp.Item2 + CircleRadius / 2 - p.Y;
                        double distance = Math.Sqrt(a * a + b * b);
                        if (distance < tmp.Item4.Width / 2 && distance < tmp.Item4.Height)
                        {
                            tmpSelectList.Add(tmp);
                        }
                    }
                }
            }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (tmpSelectList.Count > 0)
            {
                foreach (var tmp in tmpSelectList)
                {
                    shapeList.Remove(tmp);
                    MainCanvas.Children.Remove(tmp.Item4);
                }
                tmpSelectList.Clear();
            }
        }

        private void SetToUnknown(object sender, RoutedEventArgs e)
        {
            if (tmpSelectList.Count == 1)
            {
                ToolTip tooltip = new ToolTip { Content = "-1234567890" };
                tmpSelectList[0].Item4.ToolTip = tooltip;
                tmpSelectList[0].Item4.Fill = Brushes.Black;

                var tmpitem = new Tuple<double, double, string, Shape>(tmpSelectList[0].Item1,
                    tmpSelectList[0].Item2, "-1234567890", tmpSelectList[0].Item4);

                shapeList.Remove(tmpSelectList[0]);
                shapeList.Add(tmpitem);
            }
            else
            {
                MessageBox.Show("Select One Point Please");
            }
        }

        private System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create();

        private byte[] getColor(string number)
        {
            int num = 1;
            int.TryParse(number, out num);
            int totalcolor = 0xFF0000;
            int step = totalcolor / 10;
            int rescolor = 0x00 + num * step;
            byte[] res = new byte[3];
            res[2] = (byte)rescolor;
            res[1] = (byte)(rescolor >> 8);
            res[0] = (byte)(rescolor >> 16);
            return res;
        }

        private void drawDot(double w, double h, double x, double y)
        {
            var tmpcircle = new Ellipse();

            ToolTip tooltip = new ToolTip { Content = tbClass.Text };
            tmpcircle.ToolTip = tooltip;

            tmpcircle.Width = w;
            tmpcircle.Height = h;
            tmpcircle.StrokeThickness = 0;
            byte[] arr = md5.ComputeHash(Encoding.ASCII.GetBytes(tbClass.Text));
            //arr = getColor(tbClass.Text);
            if (tbClass.Text == "-1234567890")
            {
                tmpcircle.Fill = Brushes.Black;
            }
            else
            {
                tmpcircle.Fill = new SolidColorBrush(Color.FromRgb(arr[0], arr[1], arr[2]));
            }

            MainCanvas.Children.Add(tmpcircle);
            tmpcircle.SetValue(Canvas.LeftProperty, x);
            tmpcircle.SetValue(Canvas.TopProperty, y);

            shapeList.Add(new Tuple<double, double, string, Shape>(x, y, tbClass.Text, tmpcircle));
        }

        private void drawDot(double w, double h, double x, double y, string label)
        {
            var tmpcircle = new Ellipse();

            ToolTip tooltip = new ToolTip { Content = label };
            tmpcircle.ToolTip = tooltip;

            tmpcircle.Width = w;
            tmpcircle.Height = h;
            tmpcircle.StrokeThickness = 0;
            byte[] arr = md5.ComputeHash(Encoding.ASCII.GetBytes(label));
            //arr = getColor(tbClass.Text);
            tmpcircle.Fill = new SolidColorBrush(Color.FromRgb(arr[0], arr[1], arr[2]));
            MainCanvas.Children.Add(tmpcircle);
            tmpcircle.SetValue(Canvas.LeftProperty, x);
            tmpcircle.SetValue(Canvas.TopProperty, y);
        }

        //draw x/y axes
        private void drawAxes()
        {
            Line myLine = new Line();

            myLine.Stroke = Brushes.Black;

            myLine.X1 = cavasRealWidth * 0.02;
            myLine.Y1 = cavasRealHeight / 2;

            myLine.X2 = cavasRealWidth * 0.98;
            myLine.Y2 = cavasRealHeight / 2;

            xx = (myLine.X2 - myLine.X1) / 2;

            alphaX = 1.0 / xx;

            myLine.StrokeThickness = 1;

            MainCanvas.Children.Add(myLine);

            Line myLine2 = new Line();

            myLine2.Stroke = Brushes.Black;

            myLine2.X1 = cavasRealWidth / 2;
            myLine2.Y1 = cavasRealHeight * 0.02;

            myLine2.X2 = cavasRealWidth / 2;
            myLine2.Y2 = cavasRealHeight * 0.98;

            yy = (myLine2.Y2 - myLine2.Y1) / 2;

            alphaY = -1.0 / yy;

            myLine2.StrokeThickness = 1;

            MainCanvas.Children.Add(myLine2);
        }

        private void MainCanvas_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            cavasRealHeight = e.NewSize.Height;
            cavasRealWidth = e.NewSize.Width;
        }

        private void LoadResult()
        {
            try
            {
                using (var fileStream = new System.IO.FileStream(System.IO.Path.Combine(pyPath, "Output.txt"), System.IO.FileMode.Open))
                {
                    var filereader = new System.IO.StreamReader(fileStream);
                    string line;
                    while ((line = filereader.ReadLine()) != null)
                    {
                        string[] arr = line.Split('\t');

                        if (arr.Length == 3)
                        {
                            shapeList.Add(new Tuple<double, double, string, Shape>(
                                double.Parse(arr[0]),
                                double.Parse(arr[1]),
                                arr[2],
                                null));
                        }

                        Console.WriteLine(line);
                    }
                    filereader.Close();
                }

                foreach (var tmp in shapeList)
                {
                    drawDot(CircleRadius, CircleRadius, tmp.Item1 / alphaX + xx - CircleRadius / 2, tmp.Item2 / alphaY + yy - CircleRadius / 2, tmp.Item3);
                }
            }
            catch
            {
                this.Title = "Error";
            }
        }

        private void writeToFile(object sender, RoutedEventArgs e)
        {
            if (shapeList.Count < 1) return;

            System.IO.Directory.CreateDirectory(pyPath);
            using (var fileStream = new System.IO.FileStream(System.IO.Path.Combine(pyPath, "Input.txt"), System.IO.FileMode.Create))
            {
                var filewriter = new System.IO.StreamWriter(fileStream);
                foreach (var tmp in shapeList)
                {
                    filewriter.WriteLine($"{(tmp.Item1 - xx) * alphaX}\t{(tmp.Item2 - yy) * alphaY}\t{tmp.Item3}");
                }

                filewriter.Flush();
                filewriter.Dispose();
            }

            ProcessStartInfo start = new ProcessStartInfo();
            start.FileName = "python";
            start.Arguments = System.IO.Path.Combine(pyPath, "calcOutput.py");
            start.UseShellExecute = false;
            start.RedirectStandardOutput = true;
            using (Process process = Process.Start(start))
            {
                process.WaitForExit();
            }

            MainWindow wnd2 = new MainWindow(true);
            wnd2.Show();
        }

        private bool isPopUp = false;

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (rb != null)
            {
                var text = rb.Content as string;
                if (text == "?")
                {
                    tbClass.Text = "-1234567890";
                }
                else
                {
                    tbClass.Text = text;
                }
            }

        }

        private void clear(object sender, RoutedEventArgs e)
        {
            tmpSelectList.Clear();
            foreach (var tmp in shapeList)
            {
                MainCanvas.Children.Remove(tmp.Item4);
            }
            shapeList.Clear();
        }
    }
}
