#include "pch.h"

#include <dlib/opencv.h>
#include <opencv2/highgui/highgui.hpp>
#include <dlib/image_processing/frontal_face_detector.h>
#include <dlib/image_processing/render_face_detections.h>
#include <dlib/image_processing.h>
#include <dlib/gui_widgets.h>

using namespace dlib;
using namespace std;


// ----------------------------------------------------------------------------------------

int mainAA()
{
	try
	{
		cv::VideoCapture cap(0, cv::CAP_DSHOW);
		if (!cap.isOpened())
		{
			cerr << "Unable to connect to camera" << endl;
			return 1;
		}

		if (cap.isOpened()) {
			cap.set(cv::CAP_PROP_FRAME_WIDTH, 1280);
			cap.set(cv::CAP_PROP_FRAME_HEIGHT, 720);
		}

		image_window win;

		// Load face detection and pose estimation models.
		frontal_face_detector detector = get_frontal_face_detector();
		shape_predictor pose_model;

		double t = (double)cv::getTickCount();
		//deserialize("C:/dlib/shape_predictor_5_face_landmarks.dat") >> pose_model;
		//deserialize("C:/dlib/shape_predictor_68_face_landmarks.dat") >> pose_model;
		t = (double)cv::getTickCount() - t;
		printf("landmarks load time = %g ms\n", t * 1000 / cv::getTickFrequency());

		// Grab and process frames until the main window is closed by the user.
		while (!win.is_closed())
		{
			// Grab a frame
			cv::Mat temp;
			if (!cap.read(temp))
			{
				break;
			}
			// Turn OpenCV's Mat into something dlib can deal with.  Note that this just
			// wraps the Mat object, it doesn't copy anything.  So cimg is only valid as
			// long as temp is valid.  Also don't do anything to temp that would cause it
			// to reallocate the memory which stores the image as that will make cimg
			// contain dangling pointers.  This basically means you shouldn't modify temp
			// while using cimg.

			cv_image<bgr_pixel> cimg(temp);

			// Detect faces 
			t = (double)cv::getTickCount();
			std::vector<rectangle> faces = detector(cimg);
			t = (double)cv::getTickCount() - t;
			printf("dlib detection time = %g ms\n", t * 1000 / cv::getTickFrequency());

			// Find the pose of each face.
			//std::vector<full_object_detection> shapes;
			//for (unsigned long i = 0; i < faces.size(); ++i)
			//	shapes.push_back(pose_model(cimg, faces[i]));

				// Display it all on the screen
			win.clear_overlay();
			win.set_image(cimg);
			//win.add_overlay(render_face_detections(shapes));
			win.add_overlay(faces, rgb_pixel(255, 0, 0));
		}
	}
	catch (serialization_error& e)
	{
		cout << "You need dlib's default face landmarking model file to run this example." << endl;
		cout << "You can get it from the following URL: " << endl;
		cout << "   http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2" << endl;
		cout << endl << e.what() << endl;
	}
	catch (exception& e)
	{
		cout << e.what() << endl;
	}
}

